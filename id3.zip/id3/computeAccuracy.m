function accuracy=computeAccuracy(decisionTree,testData,features,testTarget)
%% prediction for an instance
%
% Written by Zhiling Cai (zhilingcai@126.com), October 22th, 2016
%
%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% decisionTree: a struct
%       decisionTree.root
%       decisionTree.leaf
%       decisionTree.value
%       decisionTree.child    
% testData: test data matrix (mxd)
% features: feature cell array (d*1)
% testTarget: classes of testData (m*1)
%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% accuracy: accuracy of testData 
label=predictionOfInstances(decisionTree,testData,features);  % Ԥ����Լ�
temp=(label==testTarget);                                     % Ԥ����ȷ���������
accuracy=sum(temp)/length(testTarget);                        % Ԥ����ȷ�����ı���
end